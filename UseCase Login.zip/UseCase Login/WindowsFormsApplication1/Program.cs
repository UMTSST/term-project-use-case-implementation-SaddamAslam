﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        public static Form Login, Dashbord;
        public static string Name { get; set; }
        public static string id { get; set; }
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Login = new Form1();
            Dashbord = new DashBoard();
            Application.Run(Login); 
        }



        internal static void UpdatDB( string status)
        {

            DBConnection dbCon = DBConnection.Instance();
            dbCon.Close();
            dbCon.DatabaseName = "saddam";
            //dbCon.DatabaseName = "saddam";
            if (dbCon.IsConnect())
            {
                //suppose col0 and col1 are defined as VARCHAR in the DB
                //string query = "INSERT INTO `tbl_Login` (`username`, `password`) VALUES ('root', 'root')";
                string query = "UPDATE `User` SET `status`='" + status + "' WHERE id = '" + id + "'";
                var cmd = new MySqlCommand(query, dbCon.Connection);
                cmd.ExecuteNonQuery();
                // 
            }        
        }
    }
}
