﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {

        string user = "driver";
        DBConnection dbCon;
        public Form1()
        {
            InitializeComponent();
                      
        }

        void InsetData()
        {
                DBConnection dbCon = DBConnection.Instance();
                dbCon.DatabaseName = "saddam";
                //dbCon.DatabaseName = "saddam";
                if (dbCon.IsConnect())
                {
                    //suppose col0 and col1 are defined as VARCHAR in the DB
                    //string query = "INSERT INTO `tbl_Login` (`username`, `password`) VALUES ('root', 'root')";
                    string query = "INSERT INTO `User` (`username`, `password`, `status`) VALUES ('root', 'root','online')";
                    var cmd = new MySqlCommand(query, dbCon.Connection);
                    cmd.ExecuteNonQuery();
                   // 
                }
        }

        void LoginDB()
        {
            try
            {
                dbCon = DBConnection.Instance();
                dbCon.DatabaseName = "saddam";
                if (dbCon.IsConnect())
                {
                    //suppose col0 and col1 are defined as VARCHAR in the DB
                    string query = "SELECT id, username, password FROM User WHERE User = '" + user + "' and username= '" + textBox1.Text + "' and password = '" + textBox2.Text + "'";
                    //string query = "INSERT INTO `tbl_Login` (`Id`, `username`, `password`) VALUES ('', 'root', 'root')";

                    var cmd = new MySqlCommand(query, dbCon.Connection);
                    var reader = cmd.ExecuteReader();
                    String data = "", id = "";
                    
                    while (reader.Read())
                    {
                        data = reader.GetString(1);
                        id = reader.GetString(0);
                    }
                    if (data != "")
                    {
                        this.Hide();
                        Program.id = id;
                        Program.UpdatDB ("online");
                        Program.Name = data;
                        Program.Dashbord.Show();
                        MessageBox.Show("Login Sussesfull");
                    }
                    else
                    {
                        MessageBox.Show("Data Not Found \nCheck Name or Password");
                    }

                }
                
            }
            catch (Exception x)
            {
                MessageBox.Show(x+"\nDataBase Connection Failed");
            }
            dbCon.Close();
        }

        void LoginFH()
        {
            
          /*
            StreamWriter wr = new StreamWriter("User.txt", true);
            wr.WriteLine("1,pessenger,user1,user1,offline");
            wr.WriteLine("1,driver,user2,user2,offline");
            wr.Close();
          */
            StreamReader sr = null;
            if (!checkBox1.Checked)
                if (path == "")
                    MessageBox.Show("Plese Select File First");
                else
                    sr = new StreamReader(path);
            else
                sr = new StreamReader("User.txt");
            if (sr != null)
            {
                string DataLine;
                string[] DataWords;
                bool flag = false;
                while (!sr.EndOfStream)
                {
                    DataLine = sr.ReadLine();
                    DataWords = DataLine.Split(',');
                    if (DataWords[1] == user && DataWords[2] == textBox1.Text && DataWords[3] == textBox2.Text)
                    {
                        this.Hide();
                        Program.Name = DataWords[2];                       
                        Program.Dashbord.Show();
                        MessageBox.Show("Login Sussesfull");
                        flag = true;
                        break;
                    }
                }

                sr.Close();
                if (!flag)
                    MessageBox.Show("Data Not Found \nCheck Name or Password");
            }


        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.Text == "DataBase")
            {
                LoginDB();
            }
            else if (comboBox1.Text == "FileHandling")
            {
                LoginFH();
            }
            else
            {
                MessageBox.Show("Chose Data Source First");
            }
            textBox1.Text = "";
            textBox2.Text = "";
            //InsetData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Under Process");
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            user = "driver";

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            user = "pessenger";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.Text == "FileHandling")
            {
                checkBox1.Enabled = true;
                button3.Enabled = true;
            }
            else
            {
                checkBox1.Enabled = false;
                button3.Enabled = false;
            }
        }
        string path = "";

        void ChoseFile()
        {
            OpenFileDialog open = new OpenFileDialog();
            open.Filter = "Text Document(*.txt)|*.txt";
            if(open.ShowDialog()==DialogResult.OK)
            {
                //richTextBox1.LoadFile(open.FileName, RichTextBoxStreamType.PlainText);
            }
            //this.Text = open.FileName;
            if (open.FileName != "")
            {
                button3.Text = open.FileName;
                path = open.FileName;
                //MessageBox.Show(open.FileName);
            }
            else
            {
                button3.Text = "Chose File";
                MessageBox.Show("Plese Chose .TXT File \nOr Select Auto Chose File");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            ChoseFile();
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                button3.Text = "Chose File";
                path = "";
                button3.Enabled = false;
            }
            else
                button3.Enabled = true;
        }

    }
}
